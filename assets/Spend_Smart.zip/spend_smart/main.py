import sys
from PyQt6.QtWidgets import QApplication

from core.datas import data_init
from core.views.login_window import LoginWindow


if __name__ == "__main__":
    data_init()
    app = QApplication(sys.argv)
    login_window = LoginWindow()
    login_window.show()
    sys.exit(app.exec())