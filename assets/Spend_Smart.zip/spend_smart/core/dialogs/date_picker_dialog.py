from PyQt6.QtWidgets import QDialog, QCalendarWidget


class DatePickerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Выбор даты")
        self.setGeometry(100, 100, 400, 300)

        self.calendar = QCalendarWidget(self)
        self.calendar.setGeometry(10, 10, 380, 280)
        self.calendar.setGridVisible(True)

        self.selected_date = None

        self.calendar.clicked.connect(self.set_date)
        self.exec()

    def set_date(self, date):
        self.selected_date = date
        self.accept()