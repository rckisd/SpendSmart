import sys

from PyQt6.QtWidgets import QApplication, QDialog, QVBoxLayout, QLabel, QDateEdit, QPushButton, QHBoxLayout
from PyQt6.QtCore import QDate

class DateRangeDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Select Date Range")
        self.selected_dates = None

        layout = QVBoxLayout()

        # Start date
        start_date_layout = QHBoxLayout()
        start_date_label = QLabel("Начальная дата:")
        self.start_date_edit = QDateEdit()
        self.start_date_edit.setCalendarPopup(True)
        self.start_date_edit.setDate(QDate.currentDate())
        start_date_layout.addWidget(start_date_label)
        start_date_layout.addWidget(self.start_date_edit)

        # End date
        end_date_layout = QHBoxLayout()
        end_date_label = QLabel("Конечная дата:")
        self.end_date_edit = QDateEdit()
        self.end_date_edit.setCalendarPopup(True)
        self.end_date_edit.setDate(QDate.currentDate())
        end_date_layout.addWidget(end_date_label)
        end_date_layout.addWidget(self.end_date_edit)

        # Buttons
        button_layout = QHBoxLayout()
        self.ok_button = QPushButton("Окей")
        self.ok_button.clicked.connect(self.accept)
        self.cancel_button = QPushButton("Отменить")
        self.cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(self.ok_button)
        button_layout.addWidget(self.cancel_button)

        # Add layouts to main layout
        layout.addLayout(start_date_layout)
        layout.addLayout(end_date_layout)
        layout.addLayout(button_layout)
        self.setLayout(layout)