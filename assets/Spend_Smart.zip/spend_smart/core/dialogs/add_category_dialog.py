from PyQt6.QtWidgets import QDialog, QLineEdit, QPushButton, QVBoxLayout, QLabel, QHBoxLayout, QColorDialog


class AddCategoryDialog(QDialog):
    """Диалог для добавления новой категории."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить категорию")
        self.setFixedSize(300, 200)

        self.category_name_input = QLineEdit()
        self.category_name_input.setPlaceholderText("Введите название категории")
        self.category_name_input.setStyleSheet("padding: 10px;")

        self.color_button = QPushButton("Выбрать цвет")
        self.color_button.setStyleSheet("padding: 10px;")
        self.color_button.clicked.connect(self.choose_color)

        self.selected_color = None

        add_button = QPushButton("Добавить")
        add_button.clicked.connect(self.accept)
        add_button.setStyleSheet("padding: 10px;")

        cancel_button = QPushButton("Отмена")
        cancel_button.clicked.connect(self.reject)
        cancel_button.setStyleSheet("padding: 10px;")

        layout = QVBoxLayout()
        layout.addWidget(QLabel("Название категории:"))
        layout.addWidget(self.category_name_input)
        layout.addWidget(self.color_button)

        button_layout = QHBoxLayout()
        button_layout.addWidget(add_button)
        button_layout.addWidget(cancel_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def choose_color(self):
        """Выбор цвета для категории."""
        color = QColorDialog.getColor()
        if color.isValid():
            self.selected_color = color.getRgb()[:3]  # Получаем RGB
            self.color_button.setStyleSheet(
                f"background-color: rgb({self.selected_color[0]}, {self.selected_color[1]}, {self.selected_color[2]}); padding: 10px;"
            )

    def get_category_data(self):
        """Возвращает имя категории и цвет."""
        return self.category_name_input.text(), self.selected_color