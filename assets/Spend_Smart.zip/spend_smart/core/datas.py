from datetime import datetime

from core.data_utils import load_categories_from_csv, load_spends_from_csv, save_spends_to_csv, save_categories_to_csv

categories = []
spends = []


def data_init():
    """
    Инициализирует данные категорий и расходов, загружая их из CSV-файлов.

    Глобальные переменные:
    - categories: Список объектов Category, загруженных из CSV.
    - spends: Список объектов Spend, загруженных из CSV.
    """
    global categories
    global spends

    categories = load_categories_from_csv()
    spends = load_spends_from_csv(categories)


def save_spends(new_spends):
    """
    Сохраняет переданный список расходов в CSV-файл.

    :param new_spends: Список объектов Spend для сохранения.
    """
    save_spends_to_csv(new_spends)


def save_categories(new_categories):
    """
    Сохраняет переданный список категорий в CSV-файл.

    :param new_categories: Список объектов Category для сохранения.
    """
    save_categories_to_csv(new_categories)


def get_filtered_sends(spend_value, date_value):
    """
    Фильтрует список расходов по указанной дате.

    :param spend_value: Список объектов Spend для фильтрации.
    :param date_value: Дата фильтрации в виде строки "YYYY-MM-DD" или кортежа (YYYY, MM, DD).
    :return: Список объектов Spend, соответствующих указанной дате.

    :raises ValueError: Если формат даты некорректен.
    """
    if isinstance(date_value, tuple):
        date_value = f"{date_value[0]}-{date_value[1]:02d}-{date_value[2]:02d}"

    filter_date = datetime.strptime(date_value, "%Y-%m-%d").date()

    current_spends = []
    for item in spend_value:
        if item.date == filter_date.strftime("%Y-%m-%d"):
            current_spends.append(item)

    return current_spends


def get_filtered_sends_by_range(spend_value, start_date, end_date):
    """
    Фильтрует список расходов по диапазону дат.

    :param spend_value: Список объектов Spend для фильтрации.
    :param start_date: Начало диапазона (объект datetime).
    :param end_date: Конец диапазона (объект datetime).
    :return: Список объектов Spend, попадающих в диапазон дат.
    """
    current_spends = []
    for item in spend_value:
        if start_date.strftime("%Y-%m-%d") <= item.date <= end_date.strftime("%Y-%m-%d"):
            current_spends.append(item)

    return current_spends