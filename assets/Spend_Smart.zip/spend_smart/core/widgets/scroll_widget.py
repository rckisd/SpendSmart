from datetime import datetime
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame
from core import datas
from models.spend import Spend

class ScrollWidget(QWidget):
    """
    Виджет с прокручиваемым списком для отображения расходов.
    """
    def __init__(self, parent=None):
        """
        Инициализация прокручиваемого виджета.

        :param parent: Родительский виджет (опционально).
        """
        super().__init__(parent)
        self.callback_update_title = None  # Функция для обновления заголовка
        self.categories = datas.categories  # Список категорий из данных
        self.spends = datas.spends  # Список расходов из данных
        self.current_date = None  # Текущая дата для фильтрации

        # Основной макет для прокручиваемого списка
        self.layout = QVBoxLayout()
        self.layout.setContentsMargins(5, 5, 5, 5)  # Отступы
        self.layout.setSpacing(0)  # Промежутки между элементами
        self.setLayout(self.layout)

        # Словарь для хранения элементов виджета
        self.items = {}

    def setup(self, current_date, callback_update_title=None):
        """
        Устанавливает текущую дату и функцию обратного вызова для обновления заголовка.

        :param current_date: Текущая дата для фильтрации.
        :param callback_update_title: Функция обратного вызова (опционально).
        """
        self.callback_update_title = callback_update_title
        self.update_list(current_date)

    def update_list(self, current_date):
        """
        Обновляет список расходов для указанной даты.

        :param current_date: Дата для фильтрации расходов.
        """
        self.clear()  #Удаляем текущие элементы
        self.current_date = current_date

        #Получаем отфильтрованные расходы
        current_spends = datas.get_filtered_sends(self.spends, self.current_date)
        for item in current_spends:
            self.add_item(item)  #Добавляем каждый расход в виджет

        #Вызываем функцию обновления заголовка, если она установлена
        if self.callback_update_title:
            self.callback_update_title(current_spends)

    def add_item(self, item: Spend):
        """
        Добавляет элемент расхода в список.

        :param item: Объект расхода (Spend).
        """
        #Создаем рамку для элемента
        item_frame = QFrame()
        item_frame.setStyleSheet(
            f"""
            background-color: rgb{item.category.color_rgb}; 
            border-radius: 10px; 
            padding: 10px;
            """
        )
        item_frame.setFixedHeight(70)  # Фиксированная высота элемента
        item_frame.setMinimumWidth(360)  # Минимальная ширина элемента

        #Макет для рамки элемента
        item_layout = QHBoxLayout()
        item_layout.setContentsMargins(10, 5, 10, 5)

        #Добавляем метку с категорией
        category_label = QLabel(item.category.name)
        category_label.setFont(QFont("Arial", 12))
        category_label.setStyleSheet("color: white;")
        item_layout.addWidget(category_label)

        # Добавляем метку с суммой
        amount_label = QLabel(str(item.amount))
        amount_label.setFont(QFont("Arial", 12))
        amount_label.setStyleSheet("color: white;")
        item_layout.addWidget(amount_label, alignment=Qt.AlignmentFlag.AlignCenter)

        # Добавляем кнопку для удаления элемента
        delete_button = QPushButton("Удалить")
        delete_button.setStyleSheet(
            "background-color: #FF5555; "
            "color: white; "
            "font-size: 12px; "
            "border-radius: 5px; "
            "padding: 5px;"
            "border: 1px solid grey;"
        )
        delete_button.setFixedSize(80, 30)
        delete_button.clicked.connect(lambda: self.remove_item_and_data(item_frame, item))
        item_layout.addWidget(delete_button, alignment=Qt.AlignmentFlag.AlignRight)

        # Устанавливаем макет в рамку
        item_frame.setLayout(item_layout)

        # Добавляем рамку в основной макет
        self.layout.addWidget(item_frame)

        # Сохраняем элемент в словарь для управления
        self.items[item_frame] = {
            'data': item,
            "category_label": category_label,
            "amount_label": amount_label,
        }

    def remove_item_and_data(self, item_frame, item_data):
        """
        Удаляет расход и обновляет данные.

        :param item_frame: Рамка элемента виджета.
        :param item_data: Данные элемента (Spend).
        """
        self.spends.remove(item_data)  # Удаляем расход из данных
        self.remove_item(item_frame)  # Удаляем элемент из виджета
        datas.save_spends(self.spends)  # Сохраняем обновленные данные

    def remove_item(self, item_frame):
        """
        Удаляет элемент из виджета.

        :param item_frame: Рамка элемента виджета.
        """
        self.layout.removeWidget(item_frame)  # Удаляем виджет из макета
        item_frame.deleteLater()  # Удаляем виджет

        # Удаляем из словаря, если элемент существует
        if item_frame in self.items:
            del self.items[item_frame]

        # Обновляем заголовок, если установлена функция обратного вызова
        if self.callback_update_title:
            current_spends = datas.get_filtered_sends(self.spends, self.current_date)
            self.callback_update_title(current_spends)

    def clear(self):
        """
        Удаляет все элементы из виджета.
        """
        items = list(self.items.keys())  # Копируем список ключей
        for item in items:
            self.remove_item(item)  # Удаляем каждый элемент