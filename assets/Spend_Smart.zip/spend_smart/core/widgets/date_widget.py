# Импортируем необходимые модули и классы из библиотеки PyQt6
from PyQt6.QtCore import QDate, Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea

# Импорт класса DatePickerDialog из модуля dialogs.date_picker_dialog
from core.dialogs.date_picker_dialog import DatePickerDialog


class DateWidget:
    """
    Класс для создания виджета выбора даты с возможностью навигации вперед/назад.

    Атрибуты:
        current_date (QDate): Текущая выбранная дата.
        date_label (QLabel): Метка, отображающая текущую дату.
        callback (callable): Функция обратного вызова, которая будет вызвана при изменении даты.

    Методы:
        setup(callback=None):
            Настраивает виджет и возвращает его макет.

        open_date_picker(event):
            Открывает диалог выбора даты и обновляет текущее значение даты.

        go_to_previous_date(event):
            Уменьшает текущую дату на один день и вызывает функцию обратного вызова.

        go_to_next_date(event):
            Увеличивает текущую дату на один день и вызывает функцию обратного вызова.
    """

    def __init__(self):
        """
        Конструктор класса DateWidget.

        Устанавливает начальную дату текущей датой и создает метку для ее отображения.
        """
        self.current_date = QDate.currentDate()
        self.date_label = QLabel(self.current_date.toString("dd.MM.yyyy"))
        self.date_label.setFont(QFont("Arial", 14))
        self.date_label.setStyleSheet("color: #FFD700;")
        self.date_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.date_label.mousePressEvent = self.open_date_picker
        self.callback = None

    def setup(self, callback=None):
        """
        Настройка виджета выбора даты.

        Аргументы:
            callback (callable, optional): Функция обратного вызова, которая будет вызвана при изменении даты.

        Возвращает:
            QVBoxLayout: Макет виджета.
        """
        self.callback = callback

        layout = QVBoxLayout()

        # Дата с кнопками
        date_layout = QHBoxLayout()

        self.current_date = QDate.currentDate()
        self.date_label = QLabel(self.current_date.toString("dd.MM.yyyy"))
        self.date_label.setFont(QFont("Arial", 14))
        self.date_label.setStyleSheet("color: #FFD700;")
        self.date_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.date_label.mousePressEvent = self.open_date_picker

        # Кнопка "Предыдущая дата"
        prev_date_button = QPushButton("<")
        prev_date_button.setStyleSheet(
            """
            QPushButton {
                background-color: #555555;  /* Основной серый цвет */
                color: white; 
                border-radius: 10px; 
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #444444;  /* Темнее серый при наведении */
            }
            """
        )
        prev_date_button.clicked.connect(self.go_to_previous_date)

        # Кнопка "Следующая дата"
        next_date_button = QPushButton(">")
        next_date_button.setStyleSheet(
            """
            QPushButton {
                background-color: #555555;  /* Основной серый цвет */
                color: white; 
                border-radius: 10px; 
                padding: 5px;
            }
            QPushButton:hover {
                background-color: #444444;  /* Темнее серый при наведении */
            }
            """
        )
        next_date_button.clicked.connect(self.go_to_next_date)

        date_layout.addWidget(prev_date_button)
        date_layout.addWidget(self.date_label)
        date_layout.addWidget(next_date_button)

        layout.addLayout(date_layout)

        return layout

    def open_date_picker(self, event):
        """
        Открытие диалога выбора даты.

        Аргумент:
            event (QMouseEvent): Событие мыши, которое вызвало открытие диалога.

        Обновляет текущую дату и вызывает функцию обратного вызова, если она была передана.
        """
        date_picker = DatePickerDialog()
        if date_picker.selected_date:
            self.current_date = date_picker.selected_date
            self.date_label.setText(self.current_date.toString("dd.MM.yyyy"))
            if self.callback:
                self.callback()

    def go_to_previous_date(self, event):
        """
        Переход к предыдущей дате.

        Аргумент:
            event (QMouseEvent): Событие мыши, которое вызвало переход к предыдущей дате.

        Уменьшает текущую дату на один день и вызывает функцию обратного вызова, если она была передана.
        """
        self.current_date = self.current_date.addDays(-1)
        self.date_label.setText(self.current_date.toString("dd.MM.yyyy"))
        if self.callback:
            self.callback()

    def go_to_next_date(self, event):
        """
        Переход к следующей дате.

        Аргумент:
            event (QMouseEvent): Событие мыши, которое вызвало переход к следующей дате.

        Увеличивает текущую дату на один день и вызывает функцию обратного вызова, если она была передана.
        """
        self.current_date = self.current_date.addDays(1)
        self.date_label.setText(self.current_date.toString("dd.MM.yyyy"))
        if self.callback:
            self.callback()