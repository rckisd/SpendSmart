import os
import pandas as pd
from tkinter import Tk
from tkinter.filedialog import asksaveasfilename
from openpyxl import load_workbook
from openpyxl.chart import BarChart, Reference

from models.category import Category
from models.spend import Spend

def save_categories_to_csv(categories, filename='categories.csv'):
    """
    Сохраняет список категорий в CSV-файл.

    :param categories: Список объектов Category.
    :param filename: Имя CSV-файла для сохранения (по умолчанию 'categories.csv').
    """
    data = {
        'name': [cat.name for cat in categories],
        'color_r': [cat.color_rgb[0] for cat in categories],
        'color_g': [cat.color_rgb[1] for cat in categories],
        'color_b': [cat.color_rgb[2] for cat in categories]
    }
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)

def load_categories_from_csv(filename='categories.csv'):
    """
    Загружает список категорий из CSV-файла.

    :param filename: Имя CSV-файла (по умолчанию 'categories.csv').
    :return: Список объектов Category.
    """
    if not os.path.exists(filename):
        df = pd.DataFrame(columns=['name', 'color_r', 'color_g', 'color_b'])
        df.to_csv(filename, index=False)
    else:
        df = pd.read_csv(filename)

    categories = []
    for item, row in df.iterrows():
        name = row['name']
        color_rgb = (int(row['color_r']), int(row['color_g']), int(row['color_b']))
        categories.append(Category(name, color_rgb))
    return categories

def save_spends_to_csv(spends, filename='spends.csv'):
    """
    Сохраняет список расходов в CSV-файл.

    :param spends: Список объектов Spend.
    :param filename: Имя CSV-файла для сохранения (по умолчанию 'spends.csv').
    """
    data = {
        'amount': [spend.amount for spend in spends],
        'category_name': [spend.category.name for spend in spends],
        'date': [spend.date for spend in spends],
        'comment': [spend.comment for spend in spends]
    }
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)

def load_spends_from_csv(categories, filename='spends.csv'):
    """
    Загружает список расходов из CSV-файла.

    :param categories: Список объектов Category для сопоставления.
    :param filename: Имя CSV-файла (по умолчанию 'spends.csv').
    :return: Список объектов Spend.
    """
    if not os.path.exists(filename):
        df = pd.DataFrame(columns=['amount', 'category_name', 'date', 'comment'])
        df.to_csv(filename, index=False)
    else:
        df = pd.read_csv(filename)

    spends = []
    for item, row in df.iterrows():
        amount = float(row['amount'])
        category_name = row['category_name']
        date = row['date']
        comment = row['comment']
        category = next((cat for cat in categories if cat.name == category_name), None)
        if category:
            spends.append(Spend(amount, category, date, comment))
    return spends

def spends_to_dataframe(spends):
    """
    Преобразует список расходов в объект DataFrame.

    :param spends: Список объектов Spend.
    :return: DataFrame с данными о расходах.
    """
    data = {
        'amount': [spend.amount for spend in spends],
        'category_name': [spend.category.name for spend in spends],
        'date': [spend.date for spend in spends],
        'comment': [spend.comment for spend in spends]
    }
    return pd.DataFrame(data)

def export_spends_to_excel(spends):
    """
    Экспортирует список расходов в Excel-файл с добавлением графика.

    :param spends: Список объектов Spend для экспорта.
    """
    if len(spends) == 0:
        return

    df = spends_to_dataframe(spends)

    df.sort_values(by='date', inplace=True)

    root = Tk()
    root.withdraw()

    filename = asksaveasfilename(
        defaultextension=".xlsx",
        filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")]
    )

    if not filename:
        return

    df.to_excel(filename, index=False, sheet_name='Data')

    wb = load_workbook(filename)
    ws = wb['Data']

    for cell in ws['C'][1:]:
        cell.number_format = 'YYYY-MM-DD'

    chart = BarChart()
    chart.title = "Расходы по датам"
    chart.x_axis.title = 'Дата'
    chart.y_axis.title = 'Сумма'

    data = Reference(ws, min_col=1, min_row=1, max_col=1, max_row=ws.max_row)
    cats = Reference(ws, min_col=3, min_row=2, max_row=ws.max_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)

    ws.add_chart(chart, f"H2")

    wb.save(filename)