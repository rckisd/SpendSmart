import os
import ctypes
from PyQt6.QtWidgets import (
    QMainWindow,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
    QMessageBox,
)
from PyQt6.QtCore import Qt
from core.views.main_window import MainWindow

def get_current_username() -> str:
    """Получает имя текущего пользователя через Windows API."""
    buffer = ctypes.create_unicode_buffer(256)
    size = ctypes.c_ulong(len(buffer))
    if ctypes.windll.advapi32.GetUserNameW(buffer, ctypes.byref(size)):
        return buffer.value
    else:
        raise Exception("Не удалось получить имя пользователя.")


def verify_password(password: str) -> bool:
    """Проверяет пароль текущей учетной записи (только Windows)."""
    if os.name != "nt":
        raise NotImplementedError("Функция работает только на Windows")

    LOGON32_LOGON_INTERACTIVE = 2
    LOGON32_PROVIDER_DEFAULT = 0

    username = get_current_username()
    token = ctypes.c_void_p()

    try:
        result = ctypes.windll.advapi32.LogonUserW(
            username,
            None,
            password,
            LOGON32_LOGON_INTERACTIVE,
            LOGON32_PROVIDER_DEFAULT,
            ctypes.byref(token)
        )

        if result != 0:
            ctypes.windll.kernel32.CloseHandle(token)
            return True
        else:
            return False
    except Exception as e:
        print(f"Ошибка аутентификации: {e}")
        return False
    finally:
        if token:
            ctypes.windll.kernel32.CloseHandle(token)


class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.main_window = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("SpendSmart Login")
        self.setGeometry(100, 100, 400, 300)
        self.setStyleSheet("background-color: #333333;")

        main_widget = QWidget(self)
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        title_label = QLabel("SpendSmart")
        title_label.setStyleSheet("color: #FFD700; font-size: 24px; font-weight: bold;")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setStyleSheet(
            """
            QLineEdit {
                background-color: #474A51;
                border: none; 
                padding: 8px; 
                font-size: 14px;
            }
            """
        )
        layout.addWidget(self.password_input)

        login_button = QPushButton("Войти")
        login_button.setStyleSheet(
            """
            QPushButton {
                background-color: #FFD700; 
                color: black; 
                padding: 10px; 
                font-size: 14px; 
                border: none;
            }
            QPushButton:hover {
                background-color: #F4A900;
            }
            """
        )
        login_button.clicked.connect(self.authenticate_user)
        layout.addWidget(login_button)

        main_widget.setLayout(layout)
        self.setCentralWidget(main_widget)

    def authenticate_user(self):
        password = self.password_input.text()
        if verify_password(password):
            self.open_main_window()
        else:
            QMessageBox.critical(self, "Ошибка", "Неверный пароль.")

    def open_main_window(self):
        self.main_window = MainWindow()
        self.main_window.show()
        self.close()