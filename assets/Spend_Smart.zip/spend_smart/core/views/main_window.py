import sys

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

from core import datas
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QWidget,
    QScrollArea,
    QFrame,
    QStackedWidget,
    QLineEdit,
    QMessageBox, QComboBox, QDialog,
)
from core.data_utils import export_spends_to_excel
from core.dialogs.add_category_dialog import AddCategoryDialog
from core.dialogs.date_range_dialog import DateRangeDialog
from core.widgets.date_widget import DateWidget
from core.widgets.scroll_widget import ScrollWidget
from generation_data import amount
from models.category import Category
from models.spend import Spend

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SpendSmart Dashboard")
        self.setGeometry(100, 100, 400, 600)
        self.setStyleSheet("background-color: #2B2B2B; color: white;")

        # Переменные
        self.amount_label = 0
        self.current_spends = []
        self.categories = datas.categories

        # Widgets
        self.title = self.__setup_title()
        self.date_widget = DateWidget()
        self.scroll_area = QScrollArea()
        self.scroll_widget = ScrollWidget()
        self.scroll_layout = QVBoxLayout()
        self.__setup_scroll_widget()

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.home_page = QWidget()
        self.setup_home_page()

        self.add_expense_page = QWidget()
        self.setup_add_expense_page()

        self.stack.addWidget(self.home_page)
        self.stack.addWidget(self.add_expense_page)

        self.stack.setCurrentWidget(self.home_page)
        # self.__update_list_spend()
        # self.date_widget.current_date.getDate().__str__()

    def setup_home_page(self):
        layout = QVBoxLayout()

        date_layout = self.date_widget.setup(self.__update_list_spend)
        layout.addLayout(date_layout)

        current_date = self.date_widget.current_date.getDate()
        self.scroll_widget.setup(current_date, self.__update_title)

        # Заголовок
        layout.addWidget(self.title)

        # Кнопка добавления расходов
        add_button = QPushButton("Добавить")
        add_button.setStyleSheet(
            """
            QPushButton {
                background-color: #FFD700; 
                color: black; 
                font-size: 24px; 
                border-radius: 15px; 
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #F4A900;
            }
            """
        )
        add_button.clicked.connect(self.open_add_expense_page)

        # Кнопка экспорта
        export_button = QPushButton("Экспорт")
        export_button.setStyleSheet(
            """
            QPushButton {
                background-color: #FFD700; 
                color: black; 
                font-size: 24px; 
                border-radius: 15px; 
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #F4A900;
            }
            """
        )
        export_button.clicked.connect(self.__export)

        layout.addWidget(add_button, alignment=Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(self.scroll_area)

        layout.addWidget(export_button, alignment=Qt.AlignmentFlag.AlignCenter)


        self.home_page.setLayout(layout)

    def __export(self):
        current_date = self.date_widget.current_date.getDate()
        date = f"{current_date[0]}-{current_date[1]:02d}-{current_date[2]:02d}"

        date_dialog = DateRangeDialog()
        date_range = None, None
        if date_dialog.exec() == QDialog.DialogCode.Accepted:
            date_range = date_dialog.start_date_edit.date().toPyDate(), date_dialog.end_date_edit.date().toPyDate()
        else:
            return

        if not date_range:
            return

        start_date, end_date = date_range
        print(f"Selected dates: {start_date} to {end_date}")

        spand_export = datas.get_filtered_sends_by_range(datas.spends, start_date, end_date)

        export_spends_to_excel(spand_export)

    def setup_add_expense_page(self):
        layout = QVBoxLayout()

        # Заголовок
        title = QLabel("Добавление расхода")
        title.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        title.setStyleSheet("color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        # Поле ввода суммы
        self.amount_input = QLineEdit()
        self.amount_input.setPlaceholderText("Введите сумму (руб)")
        self.amount_input.setStyleSheet(
            "background-color: #333333; color: white; padding: 10px; border: 1px solid #555555; font-size: 14px;"
        )
        layout.addWidget(self.amount_input)

        # Выпадающий список категорий
        self.category_combo = QComboBox()
        self.update_category_list()
        layout.addWidget(self.category_combo)

        # Кнопка для добавления новой категории
        add_category_button = QPushButton("Добавить категорию")
        add_category_button.setStyleSheet("padding: 10px;")
        add_category_button.clicked.connect(self.add_new_category)
        layout.addWidget(add_category_button)

        # Кнопка "Добавить"
        add_expense_button = QPushButton("Добавить")
        add_expense_button.setStyleSheet(
            """
            QPushButton {
                background-color: #FFD700;
                color: black; 
                font-size: 16px; 
                padding: 10px; 
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #F4A900;
            }
            """
        )

        add_expense_button.clicked.connect(self.add_expense)
        layout.addWidget(add_expense_button, alignment=Qt.AlignmentFlag.AlignCenter)

        # Кнопка "Назад"
        back_button = QPushButton("Назад")
        back_button.setStyleSheet(
            """
            QPushButton {
                background-color: #555555;
                color: white; 
                font-size: 14px; 
                padding: 10px; 
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            """
        )
        back_button.clicked.connect(self.go_back_to_home)
        layout.addWidget(back_button, alignment=Qt.AlignmentFlag.AlignCenter)

        self.add_expense_page.setLayout(layout)

    def update_category_list(self):
        """Обновляет выпадающий список категорий."""
        self.category_combo.clear()
        for category in self.categories:
            self.category_combo.addItem(
                category.name,
                category.color_rgb,  # Сохраняем цвет как данные
            )

    def add_new_category(self):
        """Открывает диалог для добавления новой категории."""
        dialog = AddCategoryDialog()
        if dialog.exec() == QDialog.DialogCode.Accepted:
            name, color = dialog.get_category_data()
            if name and color:
                self.categories.append(Category(name, color))
                self.update_category_list()
                self.category_combo.setCurrentText(name)  # Выбираем новую категорию
            else:
                QMessageBox.warning(None, "Ошибка", "Введите имя и выберите цвет!")
            datas.save_categories(self.categories)

    def open_add_expense_page(self):
        self.stack.setCurrentWidget(self.add_expense_page)

    def add_expense(self):
        selected_category = self.category_combo.currentText()
        selected_color = self.category_combo.currentData()
        try:
            amount_input_value = self.amount_input.text().replace(',','.')
            amount = float(amount_input_value)
        except:
            QMessageBox.warning(None,'Ошибка', 'Введите корректную сумму!')

        self.amount_input.clear()
        self.stack.setCurrentWidget(self.home_page)
        current_date = self.date_widget.current_date.getDate()
        date = f"{current_date[0]}-{current_date[1]:02d}-{current_date[2]:02d}"

        spend = Spend(float(amount), Category(selected_category, selected_color), date, 'None')
        datas.spends.append(spend)
        datas.save_spends(datas.spends)

        self.__update_list_spend()

    def go_back_to_home(self):
        self.stack.setCurrentWidget(self.home_page)

    def add_expense_item(self, category: str, percentage: str, amount: str):
        """Добавляет элемент в список расходов"""
        item_frame = QFrame()
        item_frame.setStyleSheet(
            """
            background-color: #444444; 
            border-radius: 10px; 
            padding: 10px;
            margin: 5px;
            """
        )
        item_layout = QHBoxLayout()

        # Категория
        category_label = QLabel(category)
        category_label.setFont(QFont("Arial", 12))
        category_label.setStyleSheet("color: white;")
        item_layout.addWidget(category_label)

        # Сумма
        amount_label = QLabel(amount)
        amount_label.setFont(QFont("Arial", 12))
        amount_label.setStyleSheet("color: white;")
        item_layout.addWidget(amount_label, alignment=Qt.AlignmentFlag.AlignRight)

        item_frame.setLayout(item_layout)
        self.scroll_layout.addWidget(item_frame)

    # создание заголовка
    def __setup_title(self) -> QLabel:
        title = QLabel(f"Итого: {self.amount_label} ₽")
        title.setStyleSheet("color: white;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        return title

    # присвоение текста к заголовку
    def __set_text_title(self, value):
        self.title.setText(f"Итого: {value:.2f} ₽")

    def __setup_scroll_widget(self):
        # Прокручиваемая область
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("background-color: #333333;")

        # Подключаем `ScrollWidget`
        self.scroll_area.setWidget(self.scroll_widget)

    def __update_list_spend(self):
        current_date = self.date_widget.current_date.getDate()
        self.scroll_widget.update_list(current_date)

    def __update_title(self, current_spends):
        spend_sum = 0
        for item in current_spends:
            spend_sum += item.amount
        self.__set_text_title(spend_sum)


if __name__ == "__main__":

    app = QApplication([])
    main_window = MainWindow()
    main_window.show()
    app.exec()