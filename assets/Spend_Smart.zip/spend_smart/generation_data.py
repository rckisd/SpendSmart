import random
from datetime import datetime, timedelta

# Импортируем утилиты для работы с данными
from core.data_utils import save_categories_to_csv, save_spends_to_csv
from models.category import Category
from models.spend import Spend

# Инициализируем список категорий
categories = []

# Предустановленный список названий категорий
category_names = ['Продукты', 'Транспорт', 'Развлечения', 'Здоровье', 'Образование', 'Одежда', 'Подарки']

for name in category_names:
    # Генерация случайного цвета в формате RGB
    color_rgb = (
        random.randint(0, 255),  # Случайное значение для красного канала
        random.randint(0, 255),  # Случайное значение для зеленого канала
        random.randint(0, 255)   # Случайное значение для синего канала
    )
    # Создаем объект категории
    category = Category(name, color_rgb)
    # Добавляем категорию в список
    categories.append(category)

# Генерируем список расходов
spends = []

# Устанавливаем временной диапазон для генерации дат
start_date = datetime(2024, 1, 1)  # Начало года
end_date = datetime(2024, 12, 31)  # Конец года
delta_days = (end_date - start_date).days  # Количество дней в диапазоне

for i in range(1000):  # Генерируем 1000 записей расходов
    # Генерация случайной суммы от 10 до 1000, округляем до двух знаков после запятой
    amount = round(random.uniform(10, 1000), 2)
    # Выбираем случайную категорию из списка
    category = random.choice(categories)
    # Генерация случайного количества дней от начала диапазона
    random_days = random.randint(0, delta_days)
    # Рассчитываем дату, добавляя случайное количество дней к начальной дате
    date = (start_date + timedelta(days=random_days)).strftime('%Y-%m-%d')
    # Создаем комментарий для расхода
    comment = f"Автосгенерированный расход #{i + 1}"
    # Создаем объект расхода
    spend = Spend(amount, category, date, comment)
    # Добавляем расход в список
    spends.append(spend)

# Сохраняем данные категорий в CSV-файл
save_categories_to_csv(categories)

# Сохраняем данные расходов в CSV-файл
save_spends_to_csv(spends)