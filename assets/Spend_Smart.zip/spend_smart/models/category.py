class Category:
    """
    Класс Category представляет категорию с названием и цветом в формате RGB.
    """

    def __init__(self, name: str, color_rgb: tuple):
        """
        Инициализация объекта Category.

        :param name: Название категории (строка).
        :param color_rgb: Цвет категории в формате RGB (кортеж из трех чисел от 0 до 255).

        :raises Exception: Если переданы некорректные типы данных.
        """
        if not isinstance(name, str):
            raise Exception(f'Переменная name должна быть str, а не {type(name).__name__}')
        if not isinstance(color_rgb, tuple):
            raise Exception(f'Переменная color_rgb должна быть tuple, а не {type(color_rgb).__name__}')

        self.__name = name
        self.__color_rgb = color_rgb

    @property
    def name(self):
        """
        Возвращает название категории.

        :return: Название категории (строка).
        """
        return self.__name

    @name.setter
    def name(self, name: str):
        """
        Устанавливает новое название категории.

        :param name: Новое название категории (строка).

        :raises Exception: Если имя пустое или имеет некорректный тип.
        """
        if len(name) == 0:
            raise Exception('Значение имени не может быть пустым')
        if not isinstance(name, str):
            raise Exception(f'Переменная name должна быть str, а не {type(name).__name__}')

        self.__name = name

    @property
    def color_rgb(self):
        """
        Возвращает цвет категории в формате RGB.

        :return: Цвет категории (кортеж из трех чисел от 0 до 255).
        """
        return self.__color_rgb

    @color_rgb.setter
    def color_rgb(self, color_rgb: tuple):
        """
        Устанавливает новый цвет категории в формате RGB.

        :param color_rgb: Новый цвет (кортеж из трех чисел от 0 до 255).

        :raises Exception: Если цвет не является кортежем или содержит некорректные значения.
        """
        if not isinstance(color_rgb, tuple):
            raise Exception(f'Переменная color_rgb должна быть tuple, а не {type(color_rgb).__name__}')

        for item in color_rgb:
            if not isinstance(item, int):
                raise Exception(f'Элементы color_rgb должны быть int, а не {type(item).__name__}')
            if not (0 <= item <= 255):
                raise Exception('Значение каждого элемента цвета должно быть в диапазоне 0–255')

        self.__color_rgb = color_rgb