from models.category import Category


class Spend:
    """
    Класс Spend представляет расход и содержит следующие атрибуты:
    - amount: сумма расхода (float).
    - category: категория расхода (Category).
    - date: дата расхода (str).
    - comment: комментарий к расходу (str).
    """

    def __init__(self, amount: float, category: Category, date: str, comment: str):
        """
        Инициализация экземпляра класса Spend.

        :param amount: Сумма расхода (тип float).
        :param category: Категория расхода (тип Category).
        :param date: Дата расхода (строка формата YYYY-MM-DD).
        :param comment: Комментарий к расходу.

        :raises Exception: Если переданы некорректные типы данных.
        """
        if not isinstance(amount, float):
            raise Exception(f'Переменная amount должна быть float, а не {type(amount)}')
        if not isinstance(category, Category):
            raise Exception(f'Переменная category должна быть Category, а не {type(category)}')
        if not isinstance(date, str):
            raise Exception(f'Переменная date должна быть str, а не {type(date)}')

        self.__amount = amount
        self.__category = category
        self.__date = date
        self.__comment = comment

    @property
    def amount(self):
        """
        Возвращает сумму расхода.
        """
        return self.__amount

    @amount.setter
    def amount(self, amount: float):
        """
        Устанавливает сумму расхода.

        :param amount: Новое значение суммы (тип float).
        :raises Exception: Если сумма отрицательная или имеет некорректный тип.
        """
        if not isinstance(amount, float):
            raise Exception("Значение должно быть типом float")
        if amount < 0:
            raise Exception('Сумма не может быть отрицательной')

        self.__amount = amount

    @property
    def category(self):
        """
        Возвращает категорию расхода.
        """
        return self.__category

    @category.setter
    def category(self, category: Category):
        """
        Устанавливает категорию расхода.

        :param category: Новая категория расхода (тип Category).
        :raises Exception: Если передан некорректный тип данных.
        """
        if not isinstance(category, Category):
            raise Exception("Значение должно быть типом Category")

        self.__category = category

    @property
    def date(self):
        """
        Возвращает дату расхода.
        """
        return self.__date

    @date.setter
    def date(self, date: str):
        """
        Устанавливает дату расхода.

        :param date: Новая дата расхода (строка формата YYYY-MM-DD).
        :raises Exception: Если передан некорректный тип данных.
        """
        if not isinstance(date, str):
            raise Exception("Значение должно быть типом str")

        self.__date = date

    @property
    def comment(self):
        """
        Возвращает комментарий к расходу.
        """
        return self.__comment

    @comment.setter
    def comment(self, comment: str):
        """
        Устанавливает комментарий к расходу.

        :param comment: Новый комментарий (строка).
        :raises Exception: Если передан некорректный тип данных.
        """
        if not isinstance(comment, str):
            raise Exception("Значение должно быть типом str")

        self.__comment = comment